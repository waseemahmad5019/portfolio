<?php
/**
 * Template Part: Projects & Case Studies
 *
 * @package Waseem_Performance
 */
?>
<section class="projects-section" id="projects">
  <div class="container">
    
    <div class="projects-filter-bar reveal">
      <div class="section-header" style="margin-bottom: 0;">
        <span class="section-caption">// Quantifiable ROI</span>
        <h2 class="section-title">Measurable Benchmarks, <span class="highlight">Not Just Screenshots</span></h2>
      </div>

      <div class="tabs-nav">
        <button class="tab-btn active" data-filter="all">All Projects</button>
        <button class="tab-btn" data-filter="speed">Speed / CWV</button>
        <button class="tab-btn" data-filter="woocommerce">WooCommerce</button>
        <button class="tab-btn" data-filter="security">Security &amp; Fixes</button>
      </div>
    </div>

    <!-- Projects Grid -->
    <div class="projects-grid">
      
      <!-- Project 1: Upsleeve -->
      <div class="project-card spotlight-card reveal" data-category="speed woocommerce">
        <div class="project-thumb">
          <div class="project-thumb-pattern"></div>
          <span class="project-domain">upsleeve.ae</span>
          <span class="project-badge-top">+55 PTS SPEED</span>
        </div>
        <div class="project-body">
          <span class="project-tag">E-Commerce · Core Web Vitals</span>
          <h3 class="project-title">Upsleeve.ae — UAE Fashion</h3>
          <p class="project-desc">
            Optimized mobile LCP from 4.8s to 1.1s, configured Cloudflare APO edge caching, and delayed heavy social ad tracking pixels.
          </p>
          <div class="project-metrics-grid">
            <div class="metric-stat-item">
              <span class="lbl">PageSpeed Score</span>
              <span class="val">41 → 96/100</span>
            </div>
            <div class="metric-stat-item">
              <span class="lbl">Mobile LCP</span>
              <span class="val">1.1s (-77%)</span>
            </div>
          </div>
          <div class="project-footer-btn" data-project-id="upsleeve">
            <span>View Architecture Breakdown</span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </div>
        </div>
      </div>

      <!-- Project 2: SuperCloneWatches -->
      <div class="project-card spotlight-card reveal" data-category="woocommerce speed">
        <div class="project-thumb">
          <div class="project-thumb-pattern"></div>
          <span class="project-domain">superclonewatches.com</span>
          <span class="project-badge-top">HIGH CONCURRENCY</span>
        </div>
        <div class="project-body">
          <span class="project-tag">WooCommerce · Nginx Tuning</span>
          <h3 class="project-title">SuperCloneWatches Luxury Catalog</h3>
          <p class="project-desc">
            Rebuilt faceted archive filters for search engines, resolved canonical loops, and configured Redis Object Cache on high-load store.
          </p>
          <div class="project-metrics-grid">
            <div class="metric-stat-item">
              <span class="lbl">Organic Traffic</span>
              <span class="val">+38% MoM</span>
            </div>
            <div class="metric-stat-item">
              <span class="lbl">Server TTFB</span>
              <span class="val">140ms</span>
            </div>
          </div>
          <div class="project-footer-btn" data-project-id="superclone">
            <span>View Architecture Breakdown</span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </div>
        </div>
      </div>

      <!-- Project 3: BellaFoods.pk -->
      <div class="project-card spotlight-card reveal" data-category="security woocommerce">
        <div class="project-thumb">
          <div class="project-thumb-pattern"></div>
          <span class="project-domain">bellafoods.pk</span>
          <span class="project-badge-top">EMERGENCY FIX</span>
        </div>
        <div class="project-body">
          <span class="project-tag">Malware Removal · Checkout Recovery</span>
          <h3 class="project-title">BellaFoods E-Commerce</h3>
          <p class="project-desc">
            Cleaned 38 injected database tables, eradicated malicious redirect backdoors, delisted from Google blacklist in 6 hours, and restored checkout.
          </p>
          <div class="project-metrics-grid">
            <div class="metric-stat-item">
              <span class="lbl">Malware Status</span>
              <span class="val">100% Clean</span>
            </div>
            <div class="metric-stat-item">
              <span class="lbl">Checkout Drop</span>
              <span class="val">-31% Abandon</span>
            </div>
          </div>
          <div class="project-footer-btn" data-project-id="bellafoods">
            <span>View Architecture Breakdown</span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </div>
        </div>
      </div>

    </div>

  </div>
</section>
