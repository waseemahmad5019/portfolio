<?php
/**
 * Template Part: 4-Phase Process
 *
 * @package Waseem_Performance
 */
?>
<section class="process-section" id="process">
  <div class="container">
    
    <div class="section-header text-center reveal">
      <span class="section-caption">// Systematic Engineering</span>
      <h2 class="section-title">A Predictable, <span class="highlight">Zero-Guesswork Roadmap</span></h2>
      <p class="section-subtitle">
        Every project follows an exact 4-phase technical blueprint to ensure maximum speed improvements and zero site disruption.
      </p>
    </div>

    <div class="process-grid">
      
      <!-- Step 1 -->
      <div class="process-card spotlight-card active reveal">
        <div class="process-num-badge">01</div>
        <h3 class="process-title">Deep Audit &amp; Bottleneck Profiling</h3>
        <p class="process-desc">
          Full Chrome UX Report (CrUX) analysis, Waterfall breakdown, slow MySQL query logging, and plugin performance profiling.
        </p>
        <ul class="process-deliverables">
          <li>Core Web Vitals diagnostic PDF</li>
          <li>Database index inspection</li>
          <li>Script footprint inventory</li>
        </ul>
      </div>

      <!-- Step 2 -->
      <div class="process-card spotlight-card reveal">
        <div class="process-num-badge">02</div>
        <h3 class="process-title">Staging Environment Build &amp; Refactor</h3>
        <p class="process-desc">
          Safe staging replication. Clean bloatware, refactor DOM hierarchy, optimize CSS delivery, and configure Total Core Vitals plugin.
        </p>
        <ul class="process-deliverables">
          <li>Critical CSS generation</li>
          <li>JavaScript defer &amp; delay logic</li>
          <li>WooCommerce HPOS configuration</li>
        </ul>
      </div>

      <!-- Step 3 -->
      <div class="process-card spotlight-card reveal">
        <div class="process-num-badge">03</div>
        <h3 class="process-title">Server &amp; Edge Optimization</h3>
        <p class="process-desc">
          Configure Cloudflare APO / Cache Rules, Nginx microcaching, Redis object cache integration, and Gzip/Brotli compression.
        </p>
        <ul class="process-deliverables">
          <li>Cloudflare Page Rules &amp; Workers</li>
          <li>Redis persistent object cache</li>
          <li>PHP 8.2+ OPcache tuning</li>
        </ul>
      </div>

      <!-- Step 4 -->
      <div class="process-card spotlight-card reveal">
        <div class="process-num-badge">04</div>
        <h3 class="process-title">Hardening, Verification &amp; Launch</h3>
        <p class="process-desc">
          24/7 uptime monitoring setup, security hardening against brute-force attacks, zero-downtime deployment, and Google Search Console validation.
        </p>
        <ul class="process-deliverables">
          <li>Before/After benchmark reports</li>
          <li>GSC Core Web Vitals validation</li>
          <li>Automated daily cloud backups</li>
        </ul>
      </div>

    </div>

  </div>
</section>
